import os

os.environ["LOGURU_AUTOINIT"] = "False"
from mobi.extract import extract

__version__ = "0.3.3"
