from .neosynth import *

__doc__ = neosynth.__doc__
if hasattr(neosynth, "__all__"):
    __all__ = neosynth.__all__