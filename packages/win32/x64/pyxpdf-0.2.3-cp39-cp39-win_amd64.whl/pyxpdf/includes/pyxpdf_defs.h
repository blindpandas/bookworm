#if defined(_WIN32)
    #define __WIN32 1
#else
    #define __WIN32 9
#endif 
