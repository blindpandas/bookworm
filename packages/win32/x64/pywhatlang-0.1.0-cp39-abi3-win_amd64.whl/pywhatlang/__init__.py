from .pywhatlang import *

__doc__ = pywhatlang.__doc__
if hasattr(pywhatlang, "__all__"):
    __all__ = pywhatlang.__all__