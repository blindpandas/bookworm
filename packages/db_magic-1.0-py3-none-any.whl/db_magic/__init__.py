"""Original code by Cristopher Toth."""
"""Original code is licensed under The MIT licence."""

from .magic import *
